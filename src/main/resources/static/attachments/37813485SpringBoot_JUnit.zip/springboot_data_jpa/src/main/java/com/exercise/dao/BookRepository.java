package com.exercise.dao;


import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.exercise.dto.Book;  
 
//repository that extends CrudRepository  
@Repository
public interface BookRepository extends CrudRepository<Book, String>  
{

	@Query
	Book findByBookCode(@Param("code") String code);
	
} 