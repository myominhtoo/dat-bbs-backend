package com.exercise.model;

import javax.validation.constraints.NotEmpty;

public class BookBean {
	@NotEmpty(message="Book Code must not be null!")
	private String bookCode;
	@NotEmpty(message="Book Title must not be null!")
	private String bookTitle;
	@NotEmpty(message="Book Author must not be null!")
	private String bookAuthor;
	@NotEmpty(message="Book Price must not be null!")
	private String bookPrice;
	public String getBookCode() {
		return bookCode;
	}
	public void setBookCode(String bookCode) {
		this.bookCode = bookCode;
	}
	public String getBookTitle() {
		return bookTitle;
	}
	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}
	public String getBookAuthor() {
		return bookAuthor;
	}
	public void setBookAuthor(String bookAuthor) {
		this.bookAuthor = bookAuthor;
	}
	public String getBookPrice() {
		return bookPrice;
	}
	public void setBookPrice(String bookPrice) {
		this.bookPrice = bookPrice;
	}
}
