package com.exercise.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.exercise.model.BookBean;
import com.exercise.dao.BookService;
import com.exercise.dto.Book;

@Controller
public class BookController {
	@Autowired
	private BookService bookService;

	
	@RequestMapping(value="/", method=RequestMethod.GET)
	public String displayView(ModelMap model) {
		List<Book> list=bookService.getAllBooks();
		model.addAttribute("list", list);
		return "index";
	}
	
	
	
	@RequestMapping(value="/setupaddbook", method=RequestMethod.GET)
	public ModelAndView setupaddbook() {
		return new ModelAndView("addbook","bookBean",new BookBean());
	}
	
	@RequestMapping(value="/addbook", method=RequestMethod.POST)
	public String addbook(@ModelAttribute("bookBean") @Validated BookBean bean,
			BindingResult bs, ModelMap model) {
		if(bs.hasErrors()) {
			return "addbook";
		}
		Book dto=new Book();
		dto.setBookCode(bean.getBookCode());
		dto.setBookTitle(bean.getBookTitle());
		dto.setBookAuthor(bean.getBookAuthor());
		dto.setBookPrice(Double.valueOf(bean.getBookPrice()));
		bookService.save(dto);
		return "redirect:/";
	}
	
	@RequestMapping(value="/setupUpdateBook", method=RequestMethod.GET)
	public ModelAndView setupUpdatebook(@RequestParam ("code") String bookCode) {
		Book dto=bookService.getBooksByBookCode(bookCode);
		BookBean bookBean= new BookBean();
		bookBean.setBookCode(dto.getBookCode());
		bookBean.setBookTitle(dto.getBookTitle());
		bookBean.setBookAuthor(dto.getBookAuthor());
		bookBean.setBookPrice(String.valueOf(dto.getBookPrice()));
		return new ModelAndView("updatebook","bookBean",bookBean);
	}
	
	
	@RequestMapping(value="/updatebook", method=RequestMethod.POST)
	public String updatebook(@ModelAttribute("bookBean") @Validated BookBean bean,
			BindingResult bs, ModelMap model) {
		if(bs.hasErrors()) {
			return "updatebook";
		}
		Book dto=new Book();
		dto.setBookCode(bean.getBookCode());
		dto.setBookTitle(bean.getBookTitle());
		dto.setBookAuthor(bean.getBookAuthor());
		dto.setBookPrice(Double.valueOf(bean.getBookPrice()));
		bookService.update(dto);

		return "redirect:/";
	}

	@RequestMapping(value="/deleteBook", method=RequestMethod.GET)
	public String deleteBook(@RequestParam ("code")  String bookCode,ModelMap model) {
		bookService.delete(bookCode);
		return "redirect:/";
	}
}
