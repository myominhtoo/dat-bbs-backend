﻿using System.Windows;

namespace Insomnia
{
    public partial class App : Application
    {
    }
}
